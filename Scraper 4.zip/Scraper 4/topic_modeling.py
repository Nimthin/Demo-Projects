import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from gensim import corpora, models
from sklearn.cluster import KMeans
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import json

# Download necessary NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
    
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

def preprocess_text(text):
    """Clean and preprocess text data"""
    if not isinstance(text, str):
        return []
        
    # Remove URLs, mentions, hashtags, and special characters
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    text = re.sub(r'@\w+', '', text)
    text = re.sub(r'#\w+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    
    # Convert to lowercase
    text = text.lower()
    
    # Tokenize and remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in stop_words and len(word) > 2]
    
    # Lemmatize
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(word) for word in tokens]
    
    return tokens

def process_data(df):
    """Process the tweet data and generate topics and subtopics"""
    # Create a copy of the DataFrame to avoid modifying the original
    df_processed = df.copy()
    
    # Preprocess tweet text
    df_processed['tokens'] = df_processed['Tweet'].apply(preprocess_text)
    
    # Filter out empty token lists
    df_processed = df_processed[df_processed['tokens'].map(len) > 0]
    
    # Create a dictionary representation of the documents
    dictionary = corpora.Dictionary(df_processed['tokens'])
    
    # Filter out extreme values (very rare or very common words)
    dictionary.filter_extremes(no_below=2, no_above=0.9)
    
    # Convert tokenized documents into a document-term matrix
    corpus = [dictionary.doc2bow(tokens) for tokens in df_processed['tokens']]
    
    # Generate LDA model with 15-20 topics
    num_topics = 15
    lda_model = models.LdaModel(
        corpus=corpus,
        id2word=dictionary,
        num_topics=num_topics,
        passes=15,
        alpha='auto',
        random_state=42
    )
    
    # Get topic distribution for each document
    topic_distributions = [lda_model.get_document_topics(bow) for bow in corpus]
    
    # Assign the most probable topic to each document
    df_processed['main_topic'] = [
        max(dist, key=lambda x: x[1])[0] if dist else -1 
        for dist in topic_distributions
    ]
    
    # Generate topic descriptions based on top words
    topics = []
    for i in range(num_topics):
        words = lda_model.show_topic(i, 10)
        topic_words = [word for word, _ in words]
        topic_name = f"Topic {i+1}: {', '.join(topic_words[:3])}"
        topics.append({
            'id': i,
            'name': topic_name,
            'keywords': topic_words
        })
    
    # Generate subtopics using K-means clustering within each topic
    subtopics = {}
    topic_map = {}
    
    for topic_id in range(num_topics):
        # Get documents for this topic
        topic_docs = df_processed[df_processed['main_topic'] == topic_id]
        if len(topic_docs) < 3:  # Skip topics with too few documents
            subtopics[topic_id] = [{
                'id': 0,
                'name': f"General",
                'count': len(topic_docs)
            }]
            # Map all docs to the general subtopic
            for idx in topic_docs.index:
                topic_map[idx] = (topic_id, 0)
            continue
        
        # Number of subtopics (between 2-3, depending on topic size)
        n_clusters = min(3, max(2, len(topic_docs) // 10))
        
        # Get doc vectors (using topic distribution as features)
        doc_vecs = []
        for doc_idx in topic_docs.index:
            doc_vec = [0] * num_topics
            for t_id, prob in topic_distributions[doc_idx]:
                doc_vec[t_id] = prob
            doc_vecs.append(doc_vec)
        
        if len(doc_vecs) < n_clusters:  # Skip k-means if too few docs
            subtopics[topic_id] = [{
                'id': 0,
                'name': f"General",
                'count': len(topic_docs)
            }]
            # Map all docs to the general subtopic
            for idx in topic_docs.index:
                topic_map[idx] = (topic_id, 0)
            continue
        
        # Apply K-means clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        cluster_labels = kmeans.fit_predict(doc_vecs)
        
        # Add cluster info to documents
        for i, idx in enumerate(topic_docs.index):
            topic_map[idx] = (topic_id, cluster_labels[i])
        
        # Name subtopics based on most common words
        topic_subtopics = []
        for subtopic_id in range(n_clusters):
            # Get documents for this subtopic
            subtopic_docs = topic_docs.iloc[[i for i, label in enumerate(cluster_labels) if label == subtopic_id]]
            
            # Get most common words
            all_tokens = [token for tokens in subtopic_docs['tokens'] for token in tokens]
            if all_tokens:
                from collections import Counter
                common_words = [word for word, _ in Counter(all_tokens).most_common(5)]
                subtopic_name = f"Subtopic {subtopic_id+1}: {', '.join(common_words[:2])}"
            else:
                subtopic_name = f"Subtopic {subtopic_id+1}"
            
            topic_subtopics.append({
                'id': subtopic_id,
                'name': subtopic_name,
                'count': len(subtopic_docs)
            })
        
        subtopics[topic_id] = topic_subtopics
    
    return topics, subtopics, topic_map, df_processed

def get_topic_data(topic_id, topics, subtopics, topic_map, df_processed):
    """Get data for a specific topic"""
    # Get topic info
    topic = next((t for t in topics if t['id'] == topic_id), None)
    if not topic:
        return {}
    
    # Get documents for this topic
    topic_docs = df_processed[df_processed['main_topic'] == topic_id]
    
    # Get subtopics for this topic
    topic_subtopics = subtopics.get(topic_id, [])
    
    # Get time series data
    time_data = []
    if not topic_docs.empty and 'Date' in topic_docs.columns:
        topic_docs['Date'] = pd.to_datetime(topic_docs['Date'])
        daily_counts = topic_docs.groupby(topic_docs['Date'].dt.date).size()
        time_data = [{
            'date': date.strftime('%Y-%m-%d'),
            'count': count
        } for date, count in daily_counts.items()]
    
    # Get sentiment distribution
    # For this example, we'll use a very simple rule-based approach
    # In a real application, you would use a more sophisticated sentiment analysis
    positive_words = ['good', 'great', 'excellent', 'love', 'best', 'nice', 'perfect', 'happy']
    negative_words = ['bad', 'worst', 'terrible', 'hate', 'poor', 'disappointing', 'unhappy', 'awful']
    
    sentiment_counts = {'positive': 0, 'negative': 0, 'neutral': 0}
    
    for tokens in topic_docs['tokens']:
        pos_count = sum(1 for word in tokens if word in positive_words)
        neg_count = sum(1 for word in tokens if word in negative_words)
        
        if pos_count > neg_count:
            sentiment_counts['positive'] += 1
        elif neg_count > pos_count:
            sentiment_counts['negative'] += 1
        else:
            sentiment_counts['neutral'] += 1
    
    # User engagement stats
    engagement = {}
    if not topic_docs.empty:
        if 'Likes' in topic_docs.columns:
            engagement['avg_likes'] = topic_docs['Likes'].mean()
        if 'Replies' in topic_docs.columns:
            engagement['avg_replies'] = topic_docs['Replies'].mean()
        if 'Views' in topic_docs.columns:
            engagement['avg_views'] = topic_docs['Views'].mean()
    
    return {
        'topic': topic,
        'subtopics': topic_subtopics,
        'document_count': len(topic_docs),
        'time_series': time_data,
        'sentiment': sentiment_counts,
        'engagement': engagement
    }

def get_subtopic_data(topic_id, subtopic_id, subtopics, topic_map, df_processed):
    """Get data for a specific subtopic"""
    # Get subtopic info
    subtopic = next((s for s in subtopics.get(topic_id, []) if s['id'] == subtopic_id), None)
    if not subtopic:
        return {}
    
    # Get documents for this subtopic
    subtopic_docs_idx = [idx for idx, (t_id, s_id) in topic_map.items() 
                        if t_id == topic_id and s_id == subtopic_id]
    subtopic_docs = df_processed.loc[subtopic_docs_idx]
    
    # Generate word cloud data
    wordcloud_data = []
    if not subtopic_docs.empty:
        all_tokens = [token for tokens in subtopic_docs['tokens'] for token in tokens]
        from collections import Counter
        word_counts = Counter(all_tokens).most_common(30)
        wordcloud_data = [{'text': word, 'value': count} for word, count in word_counts]
    
    # Get time series data
    time_data = []
    if not subtopic_docs.empty and 'Date' in subtopic_docs.columns:
        subtopic_docs['Date'] = pd.to_datetime(subtopic_docs['Date'])
        daily_counts = subtopic_docs.groupby(subtopic_docs['Date'].dt.date).size()
        time_data = [{
            'date': date.strftime('%Y-%m-%d'),
            'count': count
        } for date, count in daily_counts.items()]
    
    # User profile analysis
    user_data = {}
    if not subtopic_docs.empty:
        if 'Location' in subtopic_docs.columns:
            locations = subtopic_docs['Location'].value_counts().head(5).to_dict()
            user_data['top_locations'] = [
                {'location': loc, 'count': count} 
                for loc, count in locations.items() if isinstance(loc, str)]
        
        if 'Followers' in subtopic_docs.columns:
            user_data['avg_followers'] = subtopic_docs['Followers'].mean()
        
        if 'Following' in subtopic_docs.columns:
            user_data['avg_following'] = subtopic_docs['Following'].mean()
    
    # User engagement stats
    engagement = {}
    if not subtopic_docs.empty:
        if 'Likes' in subtopic_docs.columns:
            engagement['avg_likes'] = subtopic_docs['Likes'].mean()
        if 'Replies' in subtopic_docs.columns:
            engagement['avg_replies'] = subtopic_docs['Replies'].mean()
        if 'Views' in subtopic_docs.columns:
            engagement['avg_views'] = subtopic_docs['Views'].mean()
    
    return {
        'subtopic': subtopic,
        'document_count': len(subtopic_docs),
        'wordcloud': wordcloud_data,
        'time_series': time_data,
        'user_data': user_data,
        'engagement': engagement
    }

def get_tweets_by_subtopic(topic_id, subtopic_id, topic_map, df_processed):
    """Get tweets for a specific subtopic"""
    # Get documents for this subtopic
    subtopic_docs_idx = [idx for idx, (t_id, s_id) in topic_map.items() 
                        if t_id == topic_id and s_id == subtopic_id]
    subtopic_docs = df_processed.loc[subtopic_docs_idx]
    
    # Prepare tweet data
    tweets = []
    if not subtopic_docs.empty:
        for _, row in subtopic_docs.iterrows():
            tweet_data = {
                'tweet': row['Tweet'],
                'author': row['Author'] if 'Author' in row else 'Unknown',
                'full_name': row['FullName'] if 'FullName' in row else '',
                'date': row['Date'].strftime('%Y-%m-%d') if 'Date' in row and pd.notna(row['Date']) else '',
                'likes': int(row['Likes']) if 'Likes' in row and pd.notna(row['Likes']) else 0,
                'replies': int(row['Replies']) if 'Replies' in row and pd.notna(row['Replies']) else 0,
                'views': int(row['Views']) if 'Views' in row and pd.notna(row['Views']) else 0,
            }
            
            # Add URL if available
            if 'TweetURL' in row and isinstance(row['TweetURL'], str):
                tweet_data['url'] = row['TweetURL']
                
            tweets.append(tweet_data)
    
    return {
        'tweets': tweets,
        'count': len(tweets)
    }

def generate_topic_visualization(topics, subtopics, df_processed):
    """Generate topic visualization data"""
    # Count documents per topic
    topic_counts = df_processed['main_topic'].value_counts().to_dict()
    
    # Prepare data for visualization
    nodes = []
    links = []
    
    # Add central node
    nodes.append({
        'id': 'center',
        'name': 'Next Brand',
        'value': len(df_processed),
        'type': 'center'
    })
    
    # Add topic nodes
    for topic in topics:
        topic_id = topic['id']
        count = topic_counts.get(topic_id, 0)
        
        nodes.append({
            'id': f'topic_{topic_id}',
            'name': topic['name'],
            'value': count,
            'type': 'topic'
        })
        
        links.append({
            'source': 'center',
            'target': f'topic_{topic_id}',
            'value': count
        })
        
        # Add subtopic nodes
        for subtopic in subtopics.get(topic_id, []):
            subtopic_id = subtopic['id']
            subtopic_count = subtopic['count']
            
            nodes.append({
                'id': f'subtopic_{topic_id}_{subtopic_id}',
                'name': subtopic['name'],
                'value': subtopic_count,
                'type': 'subtopic'
            })
            
            links.append({
                'source': f'topic_{topic_id}',
                'target': f'subtopic_{topic_id}_{subtopic_id}',
                'value': subtopic_count
            })
    
    return {
        'nodes': nodes,
        'links': links
    }
