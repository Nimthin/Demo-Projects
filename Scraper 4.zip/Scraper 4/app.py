import os
import pandas as pd
import json
from flask import Flask, render_template, jsonify
from topic_modeling import process_data, get_topic_data, get_subtopic_data, get_tweets_by_subtopic

app = Flask(__name__)

# Load and process data on startup
df = pd.read_excel('Twitter - Next.xlsx')
topics, subtopics, topic_map, df_processed = process_data(df)

@app.route('/')
def index():
    return render_template('index.html', topics=topics)

@app.route('/topics')
def get_topics():
    return jsonify(topics)

@app.route('/topic/<int:topic_id>')
def topic(topic_id):
    topic_data = get_topic_data(topic_id, topics, subtopics, topic_map, df_processed)
    return jsonify(topic_data)

@app.route('/subtopic/<int:topic_id>/<int:subtopic_id>')
def subtopic(topic_id, subtopic_id):
    subtopic_data = get_subtopic_data(topic_id, subtopic_id, subtopics, topic_map, df_processed)
    return jsonify(subtopic_data)

@app.route('/tweets/<int:topic_id>/<int:subtopic_id>')
def tweets(topic_id, subtopic_id):
    tweets_data = get_tweets_by_subtopic(topic_id, subtopic_id, topic_map, df_processed)
    return jsonify(tweets_data)

@app.route('/data')
def data():
    """Return basic statistics about the data"""
    stats = {
        'total_tweets': len(df),
        'total_topics': len(topics),
        'total_subtopics': sum(len(subtopics[topic]) for topic in subtopics),
        'avg_likes': df['Likes'].mean(),
        'avg_replies': df['Replies'].mean(),
        'date_range': [df['Date'].min().strftime('%Y-%m-%d'), df['Date'].max().strftime('%Y-%m-%d')],
    }
    return jsonify(stats)

if __name__ == '__main__':
    app.run(debug=True)
