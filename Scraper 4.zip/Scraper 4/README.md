# Next Brand Tweet Complaint Analysis Dashboard

This is an interactive web application that analyzes customer complaints and feedback tweets about the Next fashion brand. The application performs topic modeling to identify key themes in customer feedback and organizes them into topics and subtopics for easy exploration.

## Features

- Topic modeling with 15-20 main topics of discussion
- 2-3 subtopics for each main topic for deeper analysis
- Interactive visualizations including charts, graphs, and word clouds
- Tweet explorer to view original tweets for any selected subtopic
- User and engagement analysis with location and follower metrics
- Responsive, modern UI design suitable for all devices

## Data

This application uses the data from `Twitter - Next.xlsx`, which contains tweets related to the Next fashion brand along with metadata such as author information, engagement metrics, and posting dates.

## Setup and Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Installation Steps

1. Clone or download this repository
2. Install the required dependencies:

```
pip install -r requirements.txt
```

3. Run the application:

```
python app.py
```

4. Open your web browser and navigate to `http://127.0.0.1:5000`

## Project Structure

- `app.py`: Main Flask application
- `topic_modeling.py`: Topic modeling and data analysis functionality
- `templates/`: HTML templates for the web pages
- `static/`: Static files (CSS, JavaScript, images)
- `Twitter - Next.xlsx`: Data source containing tweets and metadata

## Technical Details

- **Backend**: Python with Flask web framework
- **Data Processing**: NLTK, Gensim for NLP and topic modeling
- **Visualization**: Plotly.js for interactive charts
- **Frontend**: HTML5, CSS3, Bootstrap 5, and JavaScript
- **Topic Modeling**: Latent Dirichlet Allocation (LDA) with custom subtopic clustering

## Usage

1. The dashboard loads with an overview of all topics
2. Click on a topic in the sidebar to view its details and subtopics
3. Click on a subtopic card to explore detailed analytics and view the actual tweets
4. Use the tabs in the subtopic details section to switch between different visualizations

## License

This project is for demonstration purposes only.
