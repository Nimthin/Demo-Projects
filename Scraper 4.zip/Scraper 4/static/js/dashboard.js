let currentTopicId = null;
let currentSubtopicId = null;

document.addEventListener('DOMContentLoaded', function() {
    // Fetch topics and populate the sidebar
    fetchTopics();
});

// Fetch all topics from the API
function fetchTopics() {
    fetch('/topics')
        .then(response => response.json())
        .then(topics => {
            const topicsList = document.getElementById('topics-list');
            topicsList.innerHTML = '';
            
            topics.forEach(topic => {
                const topicItem = document.createElement('a');
                topicItem.href = '#';
                topicItem.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center';
                topicItem.dataset.topicId = topic.id;
                
                const topicName = document.createElement('span');
                topicName.textContent = topic.name;
                
                const topicBadge = document.createElement('span');
                topicBadge.className = 'badge topic-count-badge';
                // Will be populated when we load the topic
                topicBadge.textContent = '0';
                
                topicItem.appendChild(topicName);
                topicItem.appendChild(topicBadge);
                
                topicItem.addEventListener('click', function(e) {
                    e.preventDefault();
                    selectTopic(topic.id);
                });
                
                topicsList.appendChild(topicItem);
            });
            
            // Select the first topic by default
            if (topics.length > 0) {
                selectTopic(topics[0].id);
            }
        })
        .catch(error => {
            console.error('Error fetching topics:', error);
        });
}

// Load and display a specific topic
function selectTopic(topicId) {
    // Update the UI state
    const topicElements = document.querySelectorAll('#topics-list a');
    topicElements.forEach(el => {
        el.classList.remove('active');
        if (parseInt(el.dataset.topicId) === topicId) {
            el.classList.add('active');
        }
    });
    
    currentTopicId = topicId;
    currentSubtopicId = null;
    
    // Show the topic overview section and hide subtopic details
    document.getElementById('topic-overview-container').style.display = 'block';
    document.getElementById('subtopics-container').style.display = 'block';
    document.getElementById('subtopic-details').style.display = 'none';
    
    // Fetch and display topic data
    fetch(`/topic/${topicId}`)
        .then(response => response.json())
        .then(data => {
            // Update topic title
            document.getElementById('selected-topic-title').textContent = data.topic.name;
            
            // Update count badge on sidebar
            const activeTopicElement = document.querySelector(`#topics-list a[data-topic-id="${topicId}"] .badge`);
            if (activeTopicElement) {
                activeTopicElement.textContent = data.document_count;
            }
            
            // Display topic keywords
            const keywordsContainer = document.getElementById('topic-keywords');
            keywordsContainer.innerHTML = '';
            data.topic.keywords.forEach(keyword => {
                const keywordTag = document.createElement('span');
                keywordTag.className = 'keyword-tag';
                keywordTag.textContent = keyword;
                keywordsContainer.appendChild(keywordTag);
            });
            
            // Render sentiment chart
            renderSentimentChart(data.sentiment);
            
            // Render time series chart
            renderTimeSeriesChart(data.time_series);
            
            // Display subtopics
            renderSubtopicsList(data.subtopics);
        })
        .catch(error => {
            console.error('Error fetching topic data:', error);
        });
}

// Render sentiment chart for a topic
function renderSentimentChart(sentimentData) {
    const sentimentChartElement = document.getElementById('topic-sentiment-chart');
    
    // Prepare data for the chart
    const labels = Object.keys(sentimentData);
    const values = Object.values(sentimentData);
    const backgroundColors = [
        'rgba(75, 192, 192, 0.6)', // positive
        'rgba(255, 99, 132, 0.6)', // negative
        'rgba(201, 203, 207, 0.6)' // neutral
    ];
    
    const data = {
        labels: labels.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
        datasets: [{
            data: values,
            backgroundColor: backgroundColors,
            borderColor: backgroundColors.map(color => color.replace('0.6', '1')),
            borderWidth: 1
        }]
    };
    
    const config = {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                },
                title: {
                    display: true,
                    text: 'Sentiment Distribution'
                }
            }
        }
    };
    
    // Create the chart using Plotly
    Plotly.newPlot(sentimentChartElement, [{
        type: 'pie',
        values: values,
        labels: labels.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
        hole: 0.4,
        marker: {
            colors: backgroundColors
        },
        textinfo: 'label+percent',
        textposition: 'outside'
    }], {
        title: 'Sentiment Distribution',
        height: 300,
        margin: {t: 40, b: 0, l: 0, r: 0}
    });
}

// Render time series chart for a topic
function renderTimeSeriesChart(timeData) {
    const timeChartElement = document.getElementById('topic-time-chart');
    
    if (!timeData || timeData.length === 0) {
        timeChartElement.innerHTML = '<p class="text-muted text-center mt-5">No time series data available</p>';
        return;
    }
    
    // Sort by date
    timeData.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Extract dates and counts
    const dates = timeData.map(item => item.date);
    const counts = timeData.map(item => item.count);
    
    // Create the chart using Plotly
    Plotly.newPlot(timeChartElement, [{
        type: 'scatter',
        mode: 'lines+markers',
        x: dates,
        y: counts,
        name: 'Tweets',
        line: {shape: 'spline', color: '#083d77'},
        marker: {size: 6, color: '#083d77'}
    }], {
        title: 'Tweet Volume Over Time',
        height: 300,
        margin: {t: 40, r: 30, l: 50, b: 50},
        xaxis: {title: 'Date'},
        yaxis: {title: 'Number of Tweets'}
    });
}

// Display subtopics for a topic
function renderSubtopicsList(subtopics) {
    const subtopicsContainer = document.getElementById('subtopics-list');
    subtopicsContainer.innerHTML = '';
    
    subtopics.forEach(subtopic => {
        const colDiv = document.createElement('div');
        colDiv.className = 'col-md-4 mb-4';
        
        const cardDiv = document.createElement('div');
        cardDiv.className = 'card subtopic-card';
        cardDiv.dataset.topicId = currentTopicId;
        cardDiv.dataset.subtopicId = subtopic.id;
        
        const cardBody = document.createElement('div');
        cardBody.className = 'card-body';
        
        const title = document.createElement('h5');
        title.className = 'card-title';
        title.textContent = subtopic.name;
        
        const count = document.createElement('p');
        count.className = 'card-text subtopic-count';
        count.innerHTML = `<i class="fas fa-comment-alt"></i> ${subtopic.count} tweets`;
        
        cardBody.appendChild(title);
        cardBody.appendChild(count);
        cardDiv.appendChild(cardBody);
        colDiv.appendChild(cardDiv);
        
        // Add click event to the subtopic card
        cardDiv.addEventListener('click', function() {
            selectSubtopic(currentTopicId, subtopic.id);
        });
        
        subtopicsContainer.appendChild(colDiv);
    });
}

// Load and display a specific subtopic
function selectSubtopic(topicId, subtopicId) {
    // Update UI state
    document.querySelectorAll('.subtopic-card').forEach(card => {
        card.classList.remove('active');
    });
    
    const selectedCard = document.querySelector(`.subtopic-card[data-topic-id="${topicId}"][data-subtopic-id="${subtopicId}"]`);
    if (selectedCard) {
        selectedCard.classList.add('active');
    }
    
    currentSubtopicId = subtopicId;
    
    // Show the subtopic details section
    document.getElementById('subtopic-details').style.display = 'block';
    
    // Fetch and display subtopic data
    fetch(`/subtopic/${topicId}/${subtopicId}`)
        .then(response => response.json())
        .then(data => {
            // Update subtopic title
            document.getElementById('selected-subtopic-title').textContent = data.subtopic.name;
            
            // Create word cloud
            if (data.wordcloud && data.wordcloud.length > 0) {
                renderWordCloud(data.wordcloud);
            } else {
                document.getElementById('subtopic-wordcloud').innerHTML = 
                    '<p class="text-muted text-center mt-5">No word cloud data available</p>';
            }
            
            // Render timeline
            if (data.time_series && data.time_series.length > 0) {
                renderSubtopicTimeline(data.time_series);
            } else {
                document.getElementById('subtopic-timeline').innerHTML = 
                    '<p class="text-muted text-center mt-5">No timeline data available</p>';
            }
            
            // Render user data charts
            renderUserDataCharts(data.user_data);
            
            // Render engagement chart
            renderEngagementChart(data.engagement);
            
            // Fetch and display tweets
            fetchTweets(topicId, subtopicId);
        })
        .catch(error => {
            console.error('Error fetching subtopic data:', error);
        });
}

// Render word cloud for a subtopic
function renderWordCloud(wordcloudData) {
    const container = document.getElementById('subtopic-wordcloud');
    
    // Create a simple word cloud using our helper function
    const words = wordcloudData.map(item => ({
        text: item.text,
        value: item.value
    }));
    
    // Create the word cloud using Plotly
    const trace = {
        type: 'scatter',
        mode: 'text',
        text: words.map(d => d.text),
        x: words.map((_, i) => Math.random()),
        y: words.map((_, i) => Math.random()),
        textfont: {
            size: words.map(d => Math.max(15, Math.min(40, 15 + d.value * 3))),
            color: words.map((_, i) => `hsl(${210 + i * 20 % 150}, 70%, ${40 + i % 30}%)`)
        },
        hoverinfo: 'text',
        textposition: 'middle center',
        hovertext: words.map(d => `${d.text} (${d.value})`)
    };

    const layout = {
        title: 'Word Cloud',
        height: 300,
        margin: {t: 40, b: 0, l: 0, r: 0},
        xaxis: {showgrid: false, zeroline: false, showticklabels: false},
        yaxis: {showgrid: false, zeroline: false, showticklabels: false},
        hovermode: 'closest'
    };

    Plotly.newPlot('subtopic-wordcloud', [trace], layout);
}

// Render timeline for a subtopic
function renderSubtopicTimeline(timeSeriesData) {
    const timelineElement = document.getElementById('subtopic-timeline');
    
    // Sort by date
    timeSeriesData.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Extract dates and counts
    const dates = timeSeriesData.map(item => item.date);
    const counts = timeSeriesData.map(item => item.count);
    
    // Create the chart using Plotly
    Plotly.newPlot(timelineElement, [{
        type: 'bar',
        x: dates,
        y: counts,
        marker: {color: '#083d77'}
    }], {
        title: 'Tweet Timeline',
        height: 300,
        margin: {t: 40, r: 10, l: 50, b: 50},
        xaxis: {title: 'Date'},
        yaxis: {title: 'Number of Tweets'}
    });
}

// Render user data charts
function renderUserDataCharts(userData) {
    // Render location chart
    const locationElement = document.getElementById('location-chart');
    if (userData && userData.top_locations && userData.top_locations.length > 0) {
        const locations = userData.top_locations.map(item => item.location);
        const counts = userData.top_locations.map(item => item.count);
        
        Plotly.newPlot(locationElement, [{
            type: 'bar',
            orientation: 'h',
            x: counts,
            y: locations,
            marker: {color: '#ff6b6b'}
        }], {
            title: 'Top User Locations',
            height: 300,
            margin: {t: 40, r: 10, l: 120, b: 30},
            xaxis: {title: 'Number of Users'}
        });
    } else {
        locationElement.innerHTML = '<p class="text-muted text-center mt-5">No location data available</p>';
    }
    
    // Render followers/following chart
    const followersElement = document.getElementById('followers-chart');
    if (userData && (userData.avg_followers || userData.avg_following)) {
        const data = [
            {name: 'Avg. Followers', value: userData.avg_followers || 0},
            {name: 'Avg. Following', value: userData.avg_following || 0}
        ];
        
        Plotly.newPlot(followersElement, [{
            type: 'bar',
            x: data.map(d => d.name),
            y: data.map(d => d.value),
            marker: {color: ['#ff9f1c', '#2ec4b6']}
        }], {
            title: 'User Network',
            height: 300,
            margin: {t: 40, r: 10, l: 50, b: 50},
            yaxis: {title: 'Average Count'}
        });
    } else {
        followersElement.innerHTML = '<p class="text-muted text-center mt-5">No follower data available</p>';
    }
}

// Render engagement chart
function renderEngagementChart(engagementData) {
    const engagementElement = document.getElementById('engagement-chart');
    
    if (engagementData && Object.keys(engagementData).length > 0) {
        const data = [
            {name: 'Likes', value: engagementData.avg_likes || 0},
            {name: 'Replies', value: engagementData.avg_replies || 0},
            {name: 'Views', value: engagementData.avg_views || 0}
        ];
        
        Plotly.newPlot(engagementElement, [{
            type: 'bar',
            x: data.map(d => d.name),
            y: data.map(d => d.value),
            marker: {color: ['#fc5185', '#3fc1c9', '#5b5f97']}
        }], {
            title: 'Average Engagement Metrics',
            height: 300,
            margin: {t: 40, r: 10, l: 50, b: 50},
            yaxis: {title: 'Average Count'}
        });
    } else {
        engagementElement.innerHTML = '<p class="text-muted text-center mt-5">No engagement data available</p>';
    }
}

// Fetch tweets for a subtopic
function fetchTweets(topicId, subtopicId) {
    fetch(`/tweets/${topicId}/${subtopicId}`)
        .then(response => response.json())
        .then(data => {
            const tweetsContainer = document.getElementById('tweets-list');
            tweetsContainer.innerHTML = '';
            
            if (data.tweets && data.tweets.length > 0) {
                data.tweets.forEach(tweet => {
                    const tweetCard = document.createElement('div');
                    tweetCard.className = 'list-group-item tweet-card';
                    
                    const tweetContent = document.createElement('div');
                    tweetContent.className = 'tweet-content';
                    
                    const tweetText = document.createElement('p');
                    tweetText.className = 'tweet-text';
                    tweetText.textContent = tweet.tweet;
                    
                    const tweetMeta = document.createElement('div');
                    tweetMeta.className = 'tweet-meta';
                    
                    const authorDate = document.createElement('div');
                    authorDate.className = 'tweet-author-date mb-2';
                    authorDate.innerHTML = `<span class="tweet-author">${tweet.full_name || tweet.author}</span> @${tweet.author} &middot; ${formatDate(tweet.date)}`;
                    
                    const tweetStats = document.createElement('div');
                    tweetStats.className = 'tweet-stats';
                    
                    const likes = document.createElement('div');
                    likes.className = 'tweet-stat';
                    likes.innerHTML = `<i class="far fa-heart"></i> ${tweet.likes}`;
                    
                    const replies = document.createElement('div');
                    replies.className = 'tweet-stat';
                    replies.innerHTML = `<i class="far fa-comment"></i> ${tweet.replies}`;
                    
                    const views = document.createElement('div');
                    views.className = 'tweet-stat';
                    views.innerHTML = `<i class="far fa-eye"></i> ${formatNumber(tweet.views)}`;
                    
                    tweetStats.appendChild(likes);
                    tweetStats.appendChild(replies);
                    tweetStats.appendChild(views);
                    
                    // Add tweet link if available
                    if (tweet.url) {
                        const tweetLink = document.createElement('a');
                        tweetLink.href = tweet.url;
                        tweetLink.target = '_blank';
                        tweetLink.className = 'btn btn-sm btn-outline-primary mt-2';
                        tweetLink.innerHTML = `<i class="fab fa-twitter"></i> View Tweet`;
                        tweetMeta.appendChild(authorDate);
                        tweetMeta.appendChild(tweetStats);
                        tweetMeta.appendChild(tweetLink);
                    } else {
                        tweetMeta.appendChild(authorDate);
                        tweetMeta.appendChild(tweetStats);
                    }
                    
                    tweetContent.appendChild(tweetText);
                    tweetContent.appendChild(tweetMeta);
                    tweetCard.appendChild(tweetContent);
                    tweetsContainer.appendChild(tweetCard);
                });
            } else {
                tweetsContainer.innerHTML = '<p class="text-center text-muted p-3">No tweets available for this subtopic</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching tweets:', error);
        });
}
