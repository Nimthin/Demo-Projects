document.addEventListener('DOMContentLoaded', function() {
    // Handle About modal
    const aboutLink = document.getElementById('about-link');
    if (aboutLink) {
        aboutLink.addEventListener('click', function(e) {
            e.preventDefault();
            const aboutModal = new bootstrap.Modal(document.getElementById('aboutModal'));
            aboutModal.show();
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Fetch basic statistics for the header
    fetchDashboardStats();
});

// Fetch and display dashboard stats
function fetchDashboardStats() {
    fetch('/data')
        .then(response => response.json())
        .then(data => {
            // Update the dashboard header stats
            document.getElementById('total-tweets').textContent = data.total_tweets;
            document.getElementById('total-topics').textContent = data.total_topics;
            
            // Format date range
            if (data.date_range && data.date_range.length === 2) {
                const startDate = new Date(data.date_range[0]);
                const endDate = new Date(data.date_range[1]);
                document.getElementById('date-range').textContent = 
                    `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`;
            } else {
                document.getElementById('date-range').textContent = 'N/A';
            }
            
            // Calculate and display average engagement
            const avgEngagement = ((data.avg_likes || 0) + (data.avg_replies || 0)).toFixed(1);
            document.getElementById('avg-engagement').textContent = avgEngagement;
        })
        .catch(error => {
            console.error('Error fetching dashboard stats:', error);
        });
}

// Helper function to format numbers
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num;
}

// Create a simple word cloud
function createWordCloud(container, words) {
    // Clear any existing content
    container.innerHTML = '';
    
    if (!words || words.length === 0) {
        container.innerHTML = '<p class="text-muted">No data available</p>';
        return;
    }
    
    // Find max and min values for scaling
    const maxValue = Math.max(...words.map(w => w.value));
    const minValue = Math.min(...words.map(w => w.value));
    
    // Create and append word elements
    words.forEach(word => {
        // Scale font size between 10 and 32 pixels based on word frequency
        const size = minValue === maxValue 
            ? 18 
            : 10 + ((word.value - minValue) / (maxValue - minValue)) * 22;
        
        const span = document.createElement('span');
        span.className = 'keyword-tag';
        span.textContent = word.text;
        span.style.fontSize = size + 'px';
        
        // Random rotation for visual interest
        const rotation = Math.floor(Math.random() * 3) * (Math.random() > 0.5 ? 1 : -1);
        span.style.transform = `rotate(${rotation}deg)`;
        
        container.appendChild(span);
    });
}

// Format date string
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString();
}
